; Script for English Adventure
; Corrected version

#define MyAppName "English Adventure"
#define MyAppVersion "1.0"
#define MyAppPublisher "School Project"
#define MyAppExeName "EnglishTrainer.exe"

[Setup]
AppId={{English-Adventure-1-0}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\English Adventure
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=C:\Users\User\Desktop
OutputBaseFilename=EnglishAdventure_Setup
SetupIconFile=C:\Users\User\Desktop\EnglishAdventure_Release\mypet.ico
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительные иконки"; Flags: unchecked

[Files]
; ГЛАВНОЕ: копируем ТОЛЬКО реально существующие файлы
Source: "C:\Users\User\Desktop\EnglishAdventure_Release\EnglishTrainer.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\User\Desktop\EnglishAdventure_Release\System.Text.Json.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\User\Desktop\EnglishAdventure_Release\mypet.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\User\Desktop\EnglishAdventure_Release\mypet.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\English Adventure"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\English Adventure"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Запустить English Adventure"; Flags: postinstall nowait skipifsilent