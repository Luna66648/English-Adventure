; English Adventure Setup Script
; Авторы: Лешан Татьяна, Ефимов Денис, Деревягина Дарья

[Setup]
AppId={{English-Adventure-2026}
AppName=English Adventure
AppVersion=1.0
AppPublisher=Лешан Татьяна, Ефимов Денис, Деревягина Дарья
DefaultDirName={autopf}\English Adventure
DefaultGroupName=English Adventure
UninstallDisplayIcon={app}\EnglishTrainer.exe
OutputDir=.
OutputBaseFilename=EnglishAdventure_Setup
SolidCompression=yes
Compression=lzma2
WizardStyle=modern
PrivilegesRequired=lowest
DisableProgramGroupPage=yes

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительные значки:"; Flags: unchecked

[Files]
; Основные файлы программы
Source: "EnglishTrainer.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "System.Text.Json.dll"; DestDir: "{app}"; Flags: ignoreversion

; Рисунки Гэрри
Source: "gerrynormal.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_sad.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_angry.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_love.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_shock.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_think.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_play.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_clean.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "gerry_sleep.png"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\English Adventure"; Filename: "{app}\EnglishTrainer.exe"
Name: "{autodesktop}\English Adventure"; Filename: "{app}\EnglishTrainer.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\EnglishTrainer.exe"; Description: "Запустить English Adventure"; Flags: postinstall nowait skipifsilent